
    function LoginCal(){
        window.location.href = '/Users/fma/Desktop/Projeto Oficial- Estatico/Telas/casdatroCons.html';
    }